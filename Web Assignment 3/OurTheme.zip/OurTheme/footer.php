<!-- Footer -->
	<p class="grid_12 footer clearfix"> <span class="float">Design By Chaozhi Zhang, Mehmood Chaudhry, Malika Chawla and Nirajana Malaiya&nbsp;&nbsp;</span> <a class="float right" href="#">top</a> </p>
</div>
<!--end wrapper-->
<?php wp_footer(); ?>
</body>
</html>