<?php get_header(); ?>
	<!-- Column 1 /Content -->
	<div class="grid_8">
		<!-- Blog Post -->
		<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
		<div class="post">
			<!-- Post Title -->
			<h3 class="title"><a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_title(); ?></a></h3>
			<!-- Post Data -->
			<p class="sub"><?php the_tags('tags：', ', ', ''); ?> &bull; <?php the_time('Y-n-j') ?> &bull; <?php comments_popup_link('0 comment', '1 comment', '% comments', '', 'comment disabled'); ?><?php edit_post_link('edit', ' &bull; ', ''); ?></p>
			<div class="hr dotted clearfix">&nbsp;</div>
			<!-- Post Image -->
			<img class="thumb" alt="" src="<?php bloginfo('template_url'); ?>/images/book_PNG2120.png" />
			<!-- Post Content -->
			<?php the_excerpt(); ?>
			<!-- Read More Button -->
			<p class="clearfix"><a href="<?php the_permalink(); ?>" class="button right">Read</a></p>
		</div>
		<div class="hr clearfix">&nbsp;</div>
		<?php endwhile; ?>

		<!-- Blog Navigation -->
		<p class="clearfix"><?php previous_posts_link('&lt;&lt; newer posts', 0); ?> <span class="float right"><?php next_posts_link(' older posts &gt;&gt;', 0); ?></span></p>
		<?php else : ?>
		<h3 class="title"><a href="#" rel="bookmark">Not found</a></h3>
		<p>No posts found！</p>
		<?php endif; ?>
	</div>
<?php get_sidebar(); ?>
<?php get_footer(); ?>