-- phpMyAdmin SQL Dump
-- version 4.4.3
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 31, 2015 at 01:55 PM
-- Server version: 5.6.24
-- PHP Version: 5.6.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `wp_bookstore`
--

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE IF NOT EXISTS `books` (
  `id` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `author` varchar(200) NOT NULL,
  `post` text NOT NULL,
  `time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`id`, `title`, `author`, `post`, `time`) VALUES
(1, 'Elon Musk: Tesla, SpaceX, and the Quest for a Fantastic Future', 'Ashlee Vance', 'In the spirit of Steve Jobs and Moneyball, Elon Musk is both an illuminating and authorized look at the extraordinary life of one of Silicon Valley''s most exciting, unpredictable, and ambitious entrepreneurs-a real-life Tony Stark-and a fascinating exploration of the renewal of American invention and its new makers.', '2015-07-31 01:14:15'),
(2, 'Losing The Signal: The Spectacular Rise And Fall Of Blackberry', 'Jacquie McNish, Sean Silcoff', 'It was a classic modern business story: two Canadian entrepreneurs build an iconic brand that would forever change the way we communicate. From its humble beginnings in an office above a bagel store in Waterloo, Ontario, BlackBerry outsmarted the global giants with an addictive smartphone that generated billions of dollars. Its devices were so ubiquitous that even President Barack Obama favoured them above all others. But just as it was emerging as the dominant global player, BlackBerry took a dramatic turn.', '2015-07-31 01:15:28'),
(3, 'Secret Garden: An Inky Treasure Hunt and Coloring Book', 'Johanna Basford', 'Tumble down the rabbit hole and find yourself in an inky black-and-white wonderland.\r\n\r\nThis interactive activity book takes you on a ramble through a secret garden created in beautifully detailed pen-and-ink illustrations-all waiting to be brought to life through coloring, but each also sheltering all kinds of tiny creatures just waiting to be found. And there are also bits of the garden that still need to be completed by you.\r\n\r\nAppealing to all ages, the intricately-realized world of the Secret Garden is both beautiful and inspirational.', '2015-07-31 01:16:48'),
(4, 'Selp-Helf', 'Miranda Sings', 'In this decidedly unhelpful, candid, hilarious "how-to" guide, YouTube personality Miranda Sings offers life lessons and tutorials with her signature sassy attitude.\r\n\r\nOver six million social media fans can''t be wrong: Miranda Sings is one of the funniest faces on YouTube. As a bumbling, ironically talentless, self-absorbed personality (a young Gilda Radner, if you will), she offers up a vlog of helpful advice every week on her widely popular YouTube channel. For the first time ever, Miranda is putting her advice to paper in this easy-to-follow guide, illustrated by Miranda herself. In it, you''ll find instructions on everything: how to get a boyfriend (wear all black and carry a fishing net), to dressing for a date (sequins and an orange tutu), to performing magic ("Magic is Lying"), and much, much more! Miranda-isms abound in these self-declared lifesaving pages, and if you don''t like it...well, as Miranda would say..."Haters, back off!"', '2015-07-31 03:29:39'),
(5, 'The Nature of the Beast: A Chief Inspector Gamache Novel', 'Louise Penny', 'Hardly a day goes by when nine year old Laurent Lepage doesn''t cry wolf. From alien invasions, to walking trees, to winged beasts in the woods, to dinosaurs spotted in the village of Three Pines, his tales are so extraordinary no one can possibly believe him. Including Armand and Reine-Marie Gamache, who now live in the little Quebec village. ', '2015-07-31 03:51:08');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE IF NOT EXISTS `comments` (
  `id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `author` varchar(200) NOT NULL,
  `comment` text NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `book_id`, `author`, `comment`, `time`) VALUES
(1, 5, 'Kenny', 'This is great!', '2015-07-31 03:45:57'),
(2, 5, 'Jimmy', 'I didn''t get it...', '2015-07-31 03:46:06'),
(3, 4, ' Timmy', ' Not bad!', '2015-07-31 03:41:33'),
(4, 4, ' Jack', ' Wow', '2015-07-31 03:40:57'),
(5, 5, ' Kyle', ' Aha!', '2015-07-31 03:46:47'),
(6, 1, ' Tony', ' Ummm.', '2015-07-31 04:17:34'),
(12, 3, ' Sam', ' Aha!', '2015-07-31 04:23:29'),
(14, 3, ' Stan', ' I wanna read this', '2015-07-31 04:25:04'),
(15, 1, ' Lucy', ' Cool stuff', '2015-07-31 04:35:15'),
(16, 4, ' Ody', ' I want this book', '2015-07-31 11:28:42');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=17;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
