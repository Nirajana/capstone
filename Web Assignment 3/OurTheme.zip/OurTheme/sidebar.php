<!-- Column 2 / Sidebar -->
    <div class="grid_4">
        <h4>Catagories</h4>
        <ul class="sidebar">
            <li><a href="">Arts</a></li>
            <li><a href="">Children</a></li>
            <li><a href="">Comics</a></li>
            <li><a href="">Education</a></li>
            <li><a href="">History</a></li>
            <li><a href="">Novel</a></li>
        </ul>
        <h4>Archives</h4>
        <ul class="sidebar">
            <li><a href="">January 2015</a></li>
            <li><a href="">December 2014</a></li>
            <li><a href="">Novemeber 2014</a></li>
            <li><a href="">October 2014</a></li>
            <li><a href="">September 2014</a></li>
            <li><a href="">August 2014</a></li>
        </ul>
               

    </div>
    <div class="hr grid_12 clearfix">&nbsp;</div>
