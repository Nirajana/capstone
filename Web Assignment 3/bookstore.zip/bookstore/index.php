<?php
    session_start();
    $user = 'root';
    $pass = '';
    $db = 'wp_bookstore';

    $conn = new mysqli('localhost', $user, $pass, $db) or die("Opps... Something went wrong...");

//echo("success");
?>

<!DOCTYPE html>
<html>
	<head>
		<title> Blog </title>
        <link rel="stylesheet" type="text/css" href="main.css">
		
    </head>
	
<body>

    <!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Blog Home - Start Bootstrap Template</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/blog-home.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    

    <!-- Page Content -->
    <div class="container">

        <div class="row">
            <div class="col-md-12">
                <div class="col-md-8">
                    <h1>Bookstore</h1>
                    
                </div>
                <div class="col-lg-4 align-right">
                    <h4>
                        <a href="index.php" >HOME</a>&nbsp;&nbsp;&nbsp;  
                        <a href="index.php">SAMPLE PAGE</a>
                    </h4>
                </div>
                
            </div>
            <div class="col-md-12">
                <h3 class="page-header">
                    A simple blog for new books and book news.
                </h3>
            </div>
            <!-- Blog Entries Column -->
            <div class="col-md-8">


                <?php
                    //create a row on table for each record
                    foreach ($conn->query('SELECT * FROM books ORDER BY time DESC LIMIT 5') as $row) {
                ?>
                
                <!-- Blog Post -->
                <h2>
                <?= "<a href='page.php?id=",$row['id'],"'>",$row['title'],"</a>";?>
                </h2>
                <p class="lead">
                    by <a href="#"><?= $row['author']?></a>
                </p>
                <p>Posted on <?= $row['time']?></p>
                <hr style="border-style: dotted;">
                <img class="img-responsive" src="css/book_PNG2120.png" alt="">
                <br/>
                <p><?= $row['post']?></p>
                <?= "<a class='btn btn-primary' href='page.php?id=",$row['id'],"'>Read More</a>";?>
                
                <hr>

                <?php
                    }
                ?>

                

                <!-- Pager -->
                <ul class="pager">
                    <li class="previous">
                        <a href="#">&larr; Older</a>
                    </li>
                    <li class="next">
                        <a href="#">Newer &rarr;</a>
                    </li>
                </ul>

            </div>

            <!-- Blog Sidebar Widgets Column -->
            <div class="col-md-4">

                <div class="block">
                    <h3>Categories</h3>
                    <div class="row col-lg-12">
                        <ul class="list-group">
                            <li class="list-group-item"><a href="#">Art</a>
                            </li>
                            <li class="list-group-item"><a href="#">Children</a>
                            </li>
                            <li class="list-group-item"><a href="#">Comics</a>
                            </li>
                            <li class="list-group-item"><a href="#">Education</a>
                            </li>
                            <li class="list-group-item"><a href="#">HIstory</a>
                            </li>
                            <li class="list-group-item"><a href="#">Novel</a>
                            </li>
                        </ul>
                    </div>
                </div>

                <div class="block">
                    <h3>Archives</h3>
                    <div class="row col-lg-12">
                        <ul class="list-group">
                            <li class="list-group-item"><a href="#">January 2015</a>
                            </li>
                            <li class="list-group-item"><a href="#">December 2014</a>
                            </li>
                            <li class="list-group-item"><a href="#">Novemeber 2014</a>
                            </li>
                        </ul>
                    </div>
                </div>
                
            </div>

        </div>
        <!-- /.row -->

        <hr>

        <!-- Footer -->
        <footer>
            <div class="row">
                <div class="col-lg-12">
                    <p>Design By Chaozhi Zhang, Mehmood Chaudhry, Malika Chawla and Nirajana Malaiya</p>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </footer>

    </div>
    <!-- /.container -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

  
</body>
</html> 